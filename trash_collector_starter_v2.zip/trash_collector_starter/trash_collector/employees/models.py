from django.db import models

# Create your models here.

# TODO: Create an Employee model with properties required by the user stories